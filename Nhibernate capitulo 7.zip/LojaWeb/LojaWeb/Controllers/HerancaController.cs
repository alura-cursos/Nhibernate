﻿using LojaWeb.DAO;
using LojaWeb.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LojaWeb.Controllers
{
    public class HerancaController : Controller
    {
        //private UsuariosDAO usuariosDAO;

        //public HerancaController(UsuariosDAO usuariosDAO)
        //{
        //    this.usuariosDAO = usuariosDAO;
        //}
        //public ActionResult FormPessoaFisica()
        //{
        //    return View();
        //}
        //public ActionResult AdicionaPessoaFisica(PessoaFisica pessoaFisica)
        //{
        //    usuariosDAO.Adiciona(pessoaFisica);
        //    return RedirectToAction("Index", "Usuarios");
        //}
        //public ActionResult FormPessoaJuridica()
        //{
        //    return View();
        //}
        //public ActionResult AdicionaPessoaJuridica(PessoaJuridica pessoaJuridica)
        //{
        //    usuariosDAO.Adiciona(pessoaJuridica);
        //    return RedirectToAction("Index", "Usuarios");
        //}
    }
}
